SELECT [NAME]
,[AddressLine1]
,[City]
,[StateProvinceName]
,[PostalCode]
,[CountryRegionName]

FROM [AdventureWorks2014].[Sales].[vStoreWithAddresses]
WHERE [CountryRegionName] = 'United Kingdom'