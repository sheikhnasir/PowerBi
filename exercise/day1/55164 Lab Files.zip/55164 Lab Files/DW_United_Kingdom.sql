SELECT
[GeographyKey], [RegionCountryName]

FROM [ContosoRetailDW].[dbo].[DimGeography]
WHERE [RegionCountryName]='United Kingdom'
;